# Safe Password Utility (Replit)
Educational password checker & generator.

## Run
Click **Run** or use Shell commands:

```
python3 safe_password_tool.py --check "P@ssw0rd123"
python3 safe_password_tool.py --generate --length 20
```

This tool is for learning and improving your password security only.
